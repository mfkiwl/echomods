# Dhvani
Low-cost, portable, super resolution ultrasound imaging system. It’s an 8-channel transceiver with 16 analog multiplexes to time-multiplex 128-
channel transducer probe data, which folds hardware by 16 times and reduces cost. 

> Feel free to ping me at hemanthrs@iisc.ac.in for further development or collaborations for this project. This project is made under the guidance of Dr. Chetan Singh Thakur at NeuRonICS lab, Indian Institute of Science. 
