# Folder for the MSU 430 US sensing MCU firmware
