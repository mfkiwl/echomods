% To plot fft of a signal defined in time domain as x


Time_sample = 8192; %number of time steps

x = I(10,:); % input signal (it can be any signal in time domain)

X = fftshift(fft(x)); % take fft of the signal 

fs = 40e6; % define sampling frequency
M = Time_sample; % number of sample in time

df=fs/M; %frequency resolution
sampleIndex = -M/2:M/2-1; %ordered index for FFT plot

f=sampleIndex*df; %x-axis index converted to ordered frequencies

stem(f,abs(X)); %magnitudes vs frequencies
xlabel('f (Hz)'); ylabel('|X(k)|'); 
title('fft of channel 10')