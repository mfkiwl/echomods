%% This code is written by Parisa Dehghanzadeh (pxd163@case.edu) on 6/29/2018 to import Echoes saved as CSV files from all channels
%into matlab then process them to make segment images and combine them togehter to make final image

% This code uses phase shift beamformimg with fixed focal point to make the sub-images

% This code can be used for both 25 and 50 percent overlap as well. 
% run the code section by section from the begining for each overlapping
% Run A-B-C-D-E-F-H-P  for 50percent overlapping
% Run A (assign N t0 88)-B-C-D-E (change the window to trapezoidal window)-G-H-P  for 25 percent overlapping

% Note: To run all sections together after assigning right value for N and define right window in part E 
% in case of 50 percent overlap, comment part G and in case of 25 percent overlap comment part F.

%% A : Change the path to diredtory containing all csv files taken by visual analog

filePath = 'C:\Parisa Research\IEEE magazine\data taken using alex system\data';

Time_sample = 8192; %number of time steps
N =120;% Number of acquired echo signals. This number is 120 for 50 percent overlapping between channels 

I = zeros(N,Time_sample); % define matrix to store all input data

% Go throuhg each csv file, store second column of that file in matrix I which is data related to echo and throw away anything else.

for i = 1:N
    fileName = [filePath '\' num2str(i),'.csv'];
    
    [num] = xlsread(fileName);
    
    I(i,:) = num(:,2);
end

%% B : Remove offset of each echo signal by sbtracting average of all data points in course of time from each data point

I_no_offset = zeros(N,Time_sample); % define a matrix to store echo data without offset in it

for i=1:N
    
    L = I(i,:); % First consider each echo signal as L 
    I_no_offset(i,:) = L - (1/Time_sample)*sum(L); % subtract average of L from each data point in L to make signal without offset

end

%% C: Apply hilbert transform to make IQ data out of signal

I_analytical = zeros(N,Time_sample); % define a matrix to save IQ data (Analytical format of each echo signal)

for i = 1:N
    xr = I_no_offset(i,:);
    x = hilbert(xr); % apply hilbert transform on each echo signal(each row)
    I_analytical(i,:) = x; 
end

%% D : Using pahse shift as beamforming technique by considering fixed focal point to make one sub-image out of each 8 signals

TR_N = 8; % current system has 8 transmitter and receiver
npts = 8; % number of angles t sweep the image area

pitch = 3.0e-05; % define pitch of transducer arrays
f0=8e6; % define center frequency
speedSound = 1520;% speed of sound in target in m/s
z_focus= 2e-2; % define fix focal depth


K = zeros(TR_N,Time_sample);
I_delayed = zeros(TR_N,Time_sample);
Phase_shift = zeros(TR_N,1); % define matris to store phase shifts
I_phased = zeros (npts,Time_sample);
I_phaseshift = zeros(N,Time_sample);
delta_t = zeros(TR_N,1);

% Compute delay profile for each channel based on its location compared to 
% arrival angles  (Here angle between -45 to 45 is devided to npts smaller
% angles) then apply delay profile on 8 echo signals and sum all of them 
% together to make one final echo related to each channel. repeat this for every channel.

for c = 1: TR_N : N
    K = I_no_offset(c: c + TR_N - 1,:);
    
    for a =1:npts, %repeat through arrival angle points
       angle = -45 + 90 * ((a-1) / (npts-1));%Calculate the planewave arrival angle
       angleRad = pi * angle / 180; % convert angle to radian
       
          for t = 1:Time_sample
              
              for i = (-TR_N/2):(TR_N/2) - 1 ,% Calculate element position and wavefront delay
                   position = i * pitch;
                   delta_t(i + (TR_N/2)+1) = (z_focus / speedSound)*(1 - sqrt(1 + (position/z_focus)^2 - 2*(position/z_focus) *sin(angleRad)));
                   Phase_shift(i + (TR_N/2)+1) = exp(2i*pi*f0*delta_t(i + (TR_N/2)+1));
                   I_delayed(i + (TR_N/2)+1,t)=( Phase_shift(i + (TR_N/2)+1))* K (i + (TR_N/2)+1,t);
              end
             
          end
          for i = 1:Time_sample
              I_phased(a,i) = sum( I_delayed(:,i));
          end
    end
    I_phaseshift(c:c + TR_N - 1 ,:) = I_phased;
end


%% E : Define a window and multiply it by each 8 rows (sub-image) at each time point

w = triang(TR_N); % triangular window for 50 percent overlap
% w = [0.3;0.7;1;1;1;1;0.7;0.3]; % trapezoidal window for 25 percent overlap 

I_win = zeros(N,Time_sample);

for j = 1: TR_N :N
    
    I_win(j:j + TR_N -1,:) = bsxfun(@times,I_phaseshift(j:j+ TR_N -1,:),w);
    
end
%% F : combine windowed images to make final image for 50 percent overlap sub images
% while combining sub-images first and last 4 triangulared signals remain intact


Imag_final = zeros(64 ,Time_sample);
Imag_final(1:4,:) = I_win(1:4,:); % substitude first 4 triangulared signals in final image
Imag_final(61:64,:) = I_win(117:120,:); % substitude last 4 triangulared signals in final image

% sum overlapped region and store as final image 
for i = 8:8:112
    
    Imag_final((i/2)+1:(i/2)+4,:) = I_win(i-3:i,:) + I_win(i+1:i+4,:);
    
end

%% G : combine windowed images to make final image for 25 percent overlap sub images
% First we need to throw away first six echos in last scan and keep last two.

A = zeros(82,Time_sample); % define a new matrix to store good data

% throw away first six echoes in 11th scans and keep last 2 echos
A(1:80,:) = I_win(1:80,:);
A(81,:) = (1/w(1,2))*I_win(87,:);
A(82,:) = (1/w(1,1))*I_win(88,:);

% compensate for effect of windowing on first and last two signals and then
% substitude them in final image first and last two signals

Imag_final(1,:)  =  (1/w(1,1)) * A(1,:);
Imag_final(2,:)  =  (1/w(1,2)) * A(2,:);
Imag_final(61,:) =  (1/w(1,2)) * A(79,:);
Imag_final(62,:) =  (1/w(1,1)) * A(80,:);
Imag_final(63:64,:) = A(81:82,:);


for i = 4:8:76
    
    Imag_final((3*i/4):(3*i/4)+3,:) = A(i-1:i+2,:);
end

for i = 8:8:72
    Imag_final((3*i/4)+1:(3*i/4)+2,:) = A(i-1:i,:) + A(i+1:i+2,:);
end


%% H : Scale the image to convert it to actual sizes

P_magnitude = abs(Imag_final); % show magnitude of image and ignore its phase 
 
P_scaled = zeros(size(P_magnitude,1),size(P_magnitude,2)/16);

 for i = 1:size(P_magnitude,1)
    for k = 1:size(P_magnitude,2)/16
        P_scaled(i,k) = sum(P_magnitude(i,16*(k-1)+1:16*k)/16);
    end
end

%% P: enhance the image quality and show the image 

F_mat = mat2gray(P_scaled); 
J = imadjust(F_mat); % increase the quality of image 

figure;imagesc(J); axis image;colorbar; colormap(gray);
% saveas(gcf,' ultrasound_image.fig')
