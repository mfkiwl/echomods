% To load .fig images as natrix in matlab use below script

d = load('figurename.fig','-mat');
d.hgS_070000
A= d.hgS_070000.children.children(1).properties.CData ;

% to show the matrix as an image
figure;imagesc(A);
axis image % keep the actual dimension of image
colormap(gray)

% to save image as a jpg image and open in imtool to enhance its contrast
imwrite(uint8(A), 'newname.jpg'); 
imtool