%% This code is written by Alex Roman (adr66@case.edu) on 3/25/2018 as a module of an automation process to rename and save CSV files for image processing.

% This code takes 8 CSV files generated from a single scan event, and labels them with a scan event number for organization. 
function channel_files_by_event(scan_event)
a ='C:\Users\Alex Roman\Documents\EECS 651\Nut Scan 1\'; % directroy that visual analog data is written
c = 'C:\Users\Alex Roman\Documents\EECS 651\Nut Scan 1 Copied\'; % directory that organizes data into scan events.
for j = (0)
    A =dir( fullfile(a, '*.csv'));
    fileNames = { A.name };
    if numel( A ) == 8
       for iFile = 1 : numel( A )
          EventNumber = num2str(scan_event);
          ChannelEvent = strcat(EventNumber,'_',fileNames(iFile));
          ChannelEvent = char(ChannelEvent);
          newName2 = fullfile(c, ChannelEvent);
          movefile( fullfile(a, fileNames{ iFile }), newName2);
       end
    end
end
end