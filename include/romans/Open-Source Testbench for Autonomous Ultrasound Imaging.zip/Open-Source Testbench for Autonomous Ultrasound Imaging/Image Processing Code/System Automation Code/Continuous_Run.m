%% This code is written by Alex Roman (adr66@case.edu) on 3/25/2018 as a module of an automation process to rename and save CSV files for image processing.

% This code keeps track of the number of generated CSV files, and executes the renaming code once a threshold is met. 
scan_events = 1; % Scan Event Counter intialization.
while (scan_events ~= 13)
    a ='C:\Users\Alex Roman\Documents\EECS 651\Nut Scan 1\'; % Directory Location storing CSV files
    A =dir( fullfile(a, '*.csv'));
    if numel( A ) == 8 %Represents the 8 Channels (A-H) which correspond to one scan event
        channel_files_by_event(scan_events); % MatLab module to group 8 CSV files into a scan event.
        scan_events = scan_events + 1;
        if scan_events == 12
        run rename_files.m %Final CSV renaming MatLab module       
        return
        end
    end
end