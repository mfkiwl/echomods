%% This code is written by Alex Roman (adr66@case.edu) on 3/25/2018 as a module of an automation process to renames a single CSV file for image processing.

% This takes the generated CSV files, and renames them as a number (Example: 1-88) for entry into the image processing code.
a = 'C:\Users\Alex Roman\Documents\EECS 651\Nut Scan 1 Copied\'; % directory that organizes data into scan events.
b = 'C:\Users\Alex Roman\Documents\EECS 651\Nut Scan 1 Renamed\'; % directory thar renamed data are storing (we should give tgis directory as input directory of image construction file)
for j = 0
    A =dir( fullfile(a, '*.csv') );
    fileNames = { A.name };
    if numel( A ) == 88
       for iFile = 1 : numel( A )
          newName = fullfile(b, sprintf( '%d.csv', iFile +j ) );
          copyfile( fullfile(a, fileNames{ iFile }), newName ); 
       end
    end
end