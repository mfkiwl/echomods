%% This code is written by Parisa Dehghanzadeh (pxd163@case.edu) on 3/25/2018 to import Echoes saved as CSV files from all channels
%into matlab then process them to make segment images and combine them togehter to make final image

% This code uses FFT beamformimg to make sub-images

% This code can be used for both 25 and 50 percent overlap as well. 
% % run the code section by section from the begining for each overlapping
% Run A-B-C-D-E-F-H-P  for 50percent overlapping
% Run A (assign N t0 88)-B-C-D-E (change the window to trapezoidal window)-G-H-P  for 25 percent overlapping

% Note: To run all sections together after assigning right value for N and define right window in part E 
% in case of 50 percent overlap, comment part G and in case of 25 percent overlap comment part F.

%% A : Change the path to diredtory containing all csv files taken by visual analog

filePath = 'C:\Parisa Research\IEEE magazine\data taken using alex system\data';

Time_sample = 8192; %number of time steps
N =120;% Number of acquired echo signals. This number is 120 for 50 percent overlapping between channels 

I = zeros(N,Time_sample); % define matrix to store all input data

% Go throuhg each csv file, store second column of that file in matrix I which is data related to echo and throw away anything else.

for i = 1:N
    fileName = [filePath '\' num2str(i),'.csv'];
    
    [num] = xlsread(fileName);
    
    I(i,:) = num(:,2);
end

%% B : Remove offset of each echo signal by sbtracting average of all data points in course of time from each data point

I_no_offset = zeros(N,Time_sample); % define a matrix to store echo data without offset in it

for i=1:N
    
    L = I(i,:); % First consider each echo signal as L 
    I_no_offset(i,:) = L - (1/Time_sample)*sum(L); % subtract average of L from each data point in L to make signal without offset

end

%% C: Apply hilbert transform to make IQ data out of signal

I_analytical = zeros(N,Time_sample); % define a matrix to save IQ data (Analytical format of each echo signal)

for i = 1:N
    xr = I_no_offset(i,:);
    x = hilbert(xr); % apply hilbert transform on each echo signal(each row)
    I_analytical(i,:) = x; 
end

%% D : Using fft as beamforming technique to make one sub-image out of each 8 signals

TR_N = 8; % current system has 8 transmitter and receiver

K = zeros(TR_N,Time_sample);
I_fft = zeros(N,Time_sample);

% Take fft of each 8 signals in each time point (in first dimension)

for i = 1: TR_N :N
    K = I_analytical(i:i + TR_N - 1,:); % store each 8 analytical format of echos in a new matrix
    I_fft(i:i + TR_N - 1,:) = (fft(K,TR_N,1));% take fft of the 2D matrix in first dimension 
end

%% E : Define a window and multiply it by each 8 rows (sub-image) at each time point

w = triang(TR_N); % triangular window for 50 percent overlap
% w = [0.3;0.7;1;1;1;1;0.7;0.3]; % trapezoidal window for 25 percent overlap 

I_win = zeros(N,Time_sample);

for j = 1: TR_N :N
    
    I_win(j:j + TR_N -1,:) = bsxfun(@times,I_fft(j:j+ TR_N -1,:),w);
    
end
%% F : combine windowed images to make final image for 50 percent overlap sub images
% while combining sub-images first and last 4 triangulared signals remain intact


Imag_final = zeros(64 ,Time_sample);
Imag_final(1:4,:) = I_win(1:4,:); % substitude first 4 triangulared signals in final image
Imag_final(61:64,:) = I_win(117:120,:); % substitude last 4 triangulared signals in final image

% sum overlapped region and store as final image 
for i = 8:8:112
    
    Imag_final((i/2)+1:(i/2)+4,:) = I_win(i-3:i,:) + I_win(i+1:i+4,:);
    
end

%% G : combine windowed images to make final image for 25 percent overlap sub images
% First we need to throw away first six echos in last scan and keep last two.

A = zeros(82,Time_sample); % define a new matrix to store good data

% throw away first six echoes in 11th scans and keep last 2 echos
A(1:80,:) = I_win(1:80,:);
A(81,:) = (1/w(1,2))*I_win(87,:);
A(82,:) = (1/w(1,1))*I_win(88,:);

% compensate for effect of windowing on first and last two signals and then
% substitude them in final image first and last two signals

Imag_final(1,:)  =  (1/w(1,1)) * A(1,:);
Imag_final(2,:)  =  (1/w(1,2)) * A(2,:);
Imag_final(61,:) =  (1/w(1,2)) * A(79,:);
Imag_final(62,:) =  (1/w(1,1)) * A(80,:);
Imag_final(63:64,:) = A(81:82,:);


for i = 4:8:76
    
    Imag_final((3*i/4):(3*i/4)+3,:) = A(i-1:i+2,:);
end

for i = 8:8:72
    Imag_final((3*i/4)+1:(3*i/4)+2,:) = A(i-1:i,:) + A(i+1:i+2,:);
end


%% H : Scale the image to convert it to actual sizes

P_magnitude = abs(Imag_final); % show magnitude of image and ignore its phase 
 
P_scaled = zeros(size(P_magnitude,1),size(P_magnitude,2)/16);

 for i = 1:size(P_magnitude,1)
    for k = 1:size(P_magnitude,2)/16
        P_scaled(i,k) = sum(P_magnitude(i,16*(k-1)+1:16*k)/16);
    end
end

%% P: enhance the image quality and show the image 

F_mat = mat2gray(P_scaled); 
J = imadjust(F_mat); % increase the quality of image 

figure;imagesc(J); axis image;colorbar; colormap(gray);
% saveas(gcf,' ultrasound_image.fig')
