import un0usb as USB
import time
import datetime
import matplotlib.pyplot as plt
import scipy.signal as signal
import json
import numpy as np

def custom_acquisition(fpga, acq_lines=1, gain=None, double_rate=False):
    if gain:
        fpga.csr.dacgain = gain
    else:
        gain = [int(100 + ((1000-100)*x*x*x/32/32/32)) for x in range(32)]
        fpga.csr.dacgain = gain
    fpga.csr.nblines = acq_lines - 1
    fpga.csr.drmode = int(double_rate)
    fpga.csr.acqstart = 1
    while (not fpga.csr.acqdone):
        time.sleep(0.01)
    fpga.read_lines(acq_lines)

    acq_res = fpga.read_lines( fpga.csr.nblines + 1 )
    allAcqs = []
    for k in range(len(acq_res)):
        allAcqs.append( fpga.line_to_voltage(acq_res[k]).tolist() )
        
    t = [x*256.0/len(acq_res[0]) for x in range(len(acq_res[0]))]

    data = {}
    data["t"] = t
    data["signal"] = allAcqs
    data["gain"] = fpga.csr.dacgain
    now = datetime.datetime.today().strftime('%Y%m%d%H%M%S')
    with open(now + '_data.json', 'w') as outfile:
        json.dump(data, outfile)


    return data

def apply_baseline_correction(y):
    MHz = 10**6
    sos = signal.butter(10, 2*MHz, fs=64*MHz, btype='highpass',
    analog=False, output='sos')
    return signal.sosfilt(sos,y)

def find_idx_of(vec, value):
    for i in range(len(vec)):
        if(vec[i] >= value):
            return i

    return 0

def make_plot(data):
    t = data["t"]
    
    idx_start = find_idx_of(t,15)
    idx_end = find_idx_of(t,50)
    print("idx_start: " + str(idx_start))
    print("idx_end: " + str(idx_end))
  

    sig = apply_baseline_correction( data["signal"][0] )
    t   = t[idx_start:idx_end]
    sig = sig[idx_start:idx_end]

    sig_env = np.abs(signal.hilbert(sig))
    sig_env = sig_env / max(sig_env)

    dt = t[1] - t[0]
    scale = 100000
    t_len   = int(1.75*scale)
    dt_step = int(dt*scale)

    ones  = [1 for x in range(0,t_len,dt_step)]
    zeros = [0 for x in range(0,t_len,dt_step)]
    

    code = []
    code = ones*3 + zeros + ones

    code_plot = code + [0 for x in range(len(t) - len(code))]

    barker = np.convolve(code,sig_env,"full")
    barker = barker / max(barker)

    fig, axs = plt.subplots(3,1)
    axs[0].plot(t, sig)
    axs[1].plot(t, sig_env)
    axs[1].plot(t, code_plot)
    axs[2].plot(barker)
    plt.xlabel("us")
    plt.ylabel("Amplitude")
    plt.show()

static_gain = [100 for x in range(32)]

fpga = USB.FpgaControl('ftdi://ftdi:2232:/', spi_freq=8E6) # init FTDI device 
fpga.reload() # reload configuration
fpga.reset() # reset fpga

#data = custom_acquisition(fpga, gain=static_gain)
data = custom_acquisition(fpga, gain=None)
make_plot(data)

#file = fpga.customAcq() # Running a standard NDT acquisition
#plot = USB.FView() # Opens a viewing object
#data = plot.readfile(file) # plots it

fpga.disconnect()
