#!/bin/bash
rm -rf *.jpg
rm -rf *.npz
