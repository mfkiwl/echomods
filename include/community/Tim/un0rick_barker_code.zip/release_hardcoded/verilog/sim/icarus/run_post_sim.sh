#!/bin/bash

rm -rf post/acq_post
rm -rf post/work.vcd
rm -rf post/acq.json
rm -rf post/acq_syn.v


SRCFILES=""
VFILES=post_files.cmd
IFS=$'\r\n' GLOBIGNORE='*' command eval 'VFILES_ARR=($(cat ${VFILES}))'
for i in "${VFILES_ARR[@]}"
do
    SRCFILES="${SRCFILES} ${i}"
done

# Synthesize
yosys -p "synth_ice40 -top acq -json acq.json " ${SRCFILES}

# Generate verilog from netlist
yosys -o acq_syn.v acq.json

# simulate
iverilog -g2005-sv -o acq_post ../../src/tb/tb_acq.v ../../src/rtl/dacctl.v ../../src/beh/adc10065/adc10065.v  acq_syn.v ice40lib/cells_no_default.v

# run
./acq_post

# cleanup
mv acq_post  post
mv work.vcd  post
mv acq.json  post
mv acq_syn.v post

