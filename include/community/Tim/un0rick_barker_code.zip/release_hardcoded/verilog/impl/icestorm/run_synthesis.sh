#!/bin/bash

# Script to run Yosys synthesis and nextpnr place'n'route

# exit when any command fails
#set -e

CUR_DIR=$PWD
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"

cd $SCRIPT_DIR

bash clean.sh

# Tools used
SYNTOOL=yosys
PRTOOL=nextpnr-ice40
STATOOL=icetime
BMAPTOOL=icepack

# Properties
FREQMHZ=64
DEVICE=hx8k
PACKAGE=tq144:4k
TOPNAME=top
SDC=settings/sdc.py
PCF=settings/un0rick.pcf
JSON=output/${TOPNAME}.json
ASC=output/${TOPNAME}.asc

# Parse Verilog sources
SRCFILES=""
VFILES=settings/file.list
IFS=$'\r\n' GLOBIGNORE='*' command eval 'VFILES_ARR=($(cat ${VFILES}))'
for i in "${VFILES_ARR[@]}"
do
    SRCFILES="${SRCFILES} ${i}"
done

# Synthesis
printf "Starting Synthesis ... "
#${SYNTOOL} -l logs/log_yosys_report "synth_ice40 -top ${TOPNAME} -json ${JSON}" ${SRCFILES}
${SYNTOOL} -p "synth_ice40 -top ${TOPNAME} -json ${JSON}" ${SRCFILES} > logs/log_yosys
printf "Done. \n"
grep -A 3 '12.48. Executing CHECK pass' logs/log_yosys
grep -i 'error' logs/log_yosys

# Place and route
printf "Starting Place and rout ..."
${PRTOOL} --seed 424242 -l output/pr.rpt --pre-pack ${SDC} --pcf ${PCF} --${DEVICE} --package ${PACKAGE} --json ${JSON} --asc ${ASC} 2> logs/log_nextpnr
printf "Done. \n"
grep -i 'error' logs/log_nextpnr

# Timing analysis
printf "Starting Timing analysis ..."
${STATOOL} -d ${DEVICE} ${ASC} -c ${FREQMHZ} -t -i | tee sta.rpt >> logs/log_timing_analysis
mv sta.rpt output
printf "Done. \n"
grep -i 'error' logs/log_timing_analysis

# Generate bitmap
printf "Generating Bitmap ..."
${BMAPTOOL} ${ASC} output/${TOPNAME}.bin
printf "Done. \n"

# Print Stats
./print_stats.py

# Flash to FPGA
iceprog output/top.bin

cd $CUR_DIR
