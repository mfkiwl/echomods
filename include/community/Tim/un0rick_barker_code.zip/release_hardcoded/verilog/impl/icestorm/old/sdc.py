ctx.addClock("ref_clk", 12)
ctx.addClock("pll_clk", 128)
ctx.addClock("sys_clk", 64)