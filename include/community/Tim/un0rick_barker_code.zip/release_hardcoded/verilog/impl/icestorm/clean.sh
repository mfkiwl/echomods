#!/bin/bash

rm -rf logs/*
rm -rf output/*
