#!/usr/bin/python

LOG_FILE="logs/log_yosys"
ICE40HX4K_NUMBER_OF_LUTS=3520

def get_number_of_cells():
    lines = None
    number_of_cells = -1
    with open(LOG_FILE,'r') as file_reader:
        lines = file_reader.readlines()

    for line in lines:
        line = line.lstrip()
        if line.startswith("Number of cells:"):
            split = " ".join(line.split())
            split = split.split()
            number_of_cells = int(split[-1])
            return number_of_cells

    return number_of_cells

def main():
    number_of_cells = get_number_of_cells()
    percentage = (number_of_cells / ICE40HX4K_NUMBER_OF_LUTS) * 100
    print("Used " + str(number_of_cells) + "/" + str(ICE40HX4K_NUMBER_OF_LUTS) + " cells")
    print("Used " + "{:.2f}".format(percentage) + "% of cells")

if __name__ == "__main__":
    main()