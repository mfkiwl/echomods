#!/bin/bash

rm -rf post/acq_post
rm -rf post/work.vcd
rm -rf post/acq.json
rm -rf post/acq_syn.v

SRCFILES_SYNTH=""
VFILES=post_files_synth.cmd
IFS=$'\r\n' GLOBIGNORE='*' command eval 'VFILES_ARR=($(cat ${VFILES}))'
for i in "${VFILES_ARR[@]}"
do
    SRCFILES_SYNTH="${SRCFILES} ${i}"
done

SRCFILES_SIM=""
VFILES=post_files_sim.cmd
IFS=$'\r\n' GLOBIGNORE='*' command eval 'VFILES_ARR=($(cat ${VFILES}))'
for i in "${VFILES_ARR[@]}"
do
    SRCFILES_SIM="${SRCFILES_SIM} ${i}"
done

# Synthesize
yosys -p "synth_ice40 -top acq -json acq.json " ${SRCFILES_SYNTH}

# Generate verilog from netlist
yosys -o acq_syn.v acq.json

# simulate
iverilog -g2005-sv -o acq_post ${SRCFILES_SIM} acq_syn.v ice40lib/cells_no_default.v

# run
./acq_post

# cleanup
mv acq_post  post
mv work.vcd  post
mv acq.json  post
mv acq_syn.v post

