import un0usb as USB
import time
import datetime
import matplotlib.pyplot as plt
import scipy.signal as signal
import json
import numpy as np

def custom_acquisition(fpga, acq_lines=1, gain=None, double_rate=False):
    if gain:
        fpga.csr.dacgain = gain
    else:
        gain = [int(100 + ((1000-100)*x*x*x/32/32/32)) for x in range(32)]
        fpga.csr.dacgain = gain
    fpga.csr.nblines = acq_lines - 1
    fpga.csr.drmode = int(double_rate)
    fpga.csr.acqstart = 1
    while (not fpga.csr.acqdone):
        time.sleep(0.01)
    fpga.read_lines(acq_lines)

    acq_res = fpga.read_lines( fpga.csr.nblines + 1 )
    allAcqs = []
    for k in range(len(acq_res)):
        allAcqs.append( fpga.line_to_voltage(acq_res[k]).tolist() )
        
    t = [x*256.0/len(acq_res[0]) for x in range(len(acq_res[0]))]

    data = {}
    data["t"] = t
    data["signal"] = allAcqs
    data["gain"] = fpga.csr.dacgain
    now = datetime.datetime.today().strftime('%Y%m%d%H%M%S')
    with open(now + '_data.json', 'w') as outfile:
        json.dump(data, outfile)


    return data

def apply_baseline_correction(y):
    MHz = 10**6
    sos = signal.butter(10, 2*MHz, fs=64*MHz, btype='highpass',
    analog=False, output='sos')
    return signal.sosfilt(sos,y)

def find_idx_of(vec, value):
    for i in range(len(vec)):
        if(vec[i] >= value):
            return i

    return 0

def make_plot(data, code_len):
    t = data["t"]
    
    idx_start = find_idx_of(t,15)
    idx_end = find_idx_of(t,50)
    print("idx_start: " + str(idx_start))
    print("idx_end: " + str(idx_end))
  

    sig = apply_baseline_correction( data["signal"][0] )
    t   = t[idx_start:idx_end]
    sig = sig[idx_start:idx_end]

    sig_env = np.abs(signal.hilbert(sig))
    sig_env = sig_env / max(sig_env)

    dt = t[1] - t[0]
    scale = 100000
    t_len   = int(1.7*scale)
    dt_step = int(dt*scale)

    ones  = [1 for x in range(0,t_len,dt_step)]
    zeros = [0 for x in range(0,t_len,dt_step)]
    

    code = []

    if code_len == -1:
        code = ones + zeros + ones

    if code_len == 5:
        code = ones*3 + zeros + ones
    if code_len == 7:
        code = ones*3 + zeros*2 + ones + zeros
    if code_len == 11:
        code = ones*3 + zeros*3 + ones + zeros*2 + ones + zeros
    if code_len == 13:
        code = ones*5 + zeros*2 + ones*2 + zeros + ones + zeros + ones


    offset = [0 for x in range(int(len(ones)*0.7))]
    code_plot = offset + code
    code_plot +=  [0 for x in range(len(t) - len(code_plot))]

    barker = np.convolve(code,sig_env,"full")
    barker = barker / max(barker)

    fig, axs = plt.subplots(3,1)
    axs[0].plot(t, sig)
    axs[1].plot(t, sig_env)
    axs[1].plot(t, code_plot)
    axs[2].plot(barker)
    plt.xlabel("us")
    plt.ylabel("Amplitude")
    plt.show()




def main():
    static_gain = [100 for x in range(32)]

    fpga = USB.FpgaControl('ftdi://ftdi:2232:/', spi_freq=8E6) # init FTDI device 
    fpga.reload() # reload configuration
    fpga.reset() # reset fpga

    code_len = 7
    fpga.csr.pulse1 = 10
    fpga.csr.pulse2 = 5
    fpga.csr.pulse3 = 200
    fpga.csr.pulse4 = 2
    fpga.csr.zero   = 190


    codelen  = 0
    codewire = 0

    if code_len == -1:
        # calibration
        codelen = 0x3
        codewire = 0b1010_0000_0000_0000

    if code_len == 5:
        # Barker Code 5
        codelen  = 0x5
        codewire = 0b1110_1000_0000_0000

    if code_len == 7:
        # Barker Code 7
        codelen  = 0x07
        codewire = 0b1110_0100_0000_0000

    if code_len == 11:
        # Barker Code 11
        codelen  = 0x0B
        codewire = 0b1110_001_0010_0000

    if code_len == 13:
        # Barker Code 13
        codelen  = 0x0D
        codewire = 0b1111_100_1101_0100

    offset = 1
    fpga.csr.codelen = codelen + offset
    fpga.csr.codewire = (codewire >> offset)

    print("fpga.csr.pulse1 :", fpga.csr.pulse1)
    print("fpga.csr.pulse2 :", fpga.csr.pulse2)
    print("fpga.csr.pulse3 :", fpga.csr.pulse3)
    print("fpga.csr.pulse4 :", fpga.csr.pulse4)
    print("fpga.csr.codelen :", fpga.csr.codelen)
    print("fpga.csr.codewire :", fpga.csr.codewire)
    print("fpga.csr.zero :", fpga.csr.zero)

    #data = custom_acquisition(fpga, gain=static_gain)
    data = custom_acquisition(fpga, gain=None)
    make_plot(data, code_len)

    #file = fpga.customAcq() # Running a standard NDT acquisition
    #plot = USB.FView() # Opens a viewing object
    #data = plot.readfile(file) # plots it

    fpga.disconnect()


if __name__ == "__main__":
    main()