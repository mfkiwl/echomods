import matplotlib.pyplot as plt
import scipy.signal as signal
import json
import numpy as np
import sys
import json

def ERROR_EXIT(msg):
    print("ERROR: " + msg)
    exit(-1)

def apply_baseline_correction(y):
    MHz = 10**6
    sos = signal.butter(10, 2*MHz, fs=64*MHz, btype='highpass',
    analog=False, output='sos')
    return signal.sosfilt(sos,y)

def find_idx_of(vec, value):
    for i in range(len(vec)):
        if(vec[i] >= value):
            return i

    return 0

def make_plot(data, code_len):
    t = data["t"]
    
    idx_start = find_idx_of(t,15)
    idx_end = find_idx_of(t,56)
    print("idx_start: " + str(idx_start))
    print("idx_end: " + str(idx_end))
  

    sig = apply_baseline_correction( data["signal"][0] )
    t   = t[idx_start:idx_end]
    sig = sig[idx_start:idx_end]

    correction = 0.8*(np.array([x/len(sig) for x in range(len(sig))]) + 0.5)
    plt.plot(correction)
    sig = [sig[i]*correction[i] for i in range(len(sig))]

    sig_env = np.abs(signal.hilbert(sig))
    sig_env = sig_env / max(sig_env)

    dt = t[1] - t[0]
    scale = 100000
    t_len   = int(1.7*scale)
    dt_step = int(dt*scale)

    ones  = [1 for x in range(0,t_len,dt_step)]
    zeros = [0 for x in range(0,t_len,dt_step)]
    

    code = []

    if code_len == -1:
        code = ones + zeros + ones

    if code_len == 5:
        code = ones*3 + zeros + ones
    if code_len == 7:
        code = ones*3 + zeros*2 + ones + zeros
    if code_len == 11:
        code = ones*3 + zeros*3 + ones + zeros*2 + ones + zeros
    if code_len == 13:
        code = ones*5 + zeros*2 + ones*2 + zeros + ones + zeros + ones


    offset = [0 for x in range(int(len(ones)*0.7))]
    code_plot = offset + code
    code_plot +=  [0 for x in range(len(t) - len(code_plot))]

    barker = np.convolve(code,sig_env,"full")
    barker = barker / max(barker)

    fig, axs = plt.subplots(3,1)
    
    axs[0].plot(t, sig)
    axs[0].set_xlabel("t in us")
    axs[0].set_ylabel("amplitude")
    axs[0].set_title("raw signal normalized")

    axs[1].plot(t, sig_env)
    axs[1].plot(t, code_plot)
    axs[1].set_xlabel("t in us")
    axs[1].set_ylabel("amplitude")
    
    axs[1].set_title("signal envelope and barker code rect sequence")

    


    print("Len Sig Raw: " + str(len(sig)))
    print("Len Sig Env: " + str(len(sig_env)))
    print("Len Sig Barker: " + str(len(barker)))
    padding_len = (len(barker) - len(sig))//2
    barker_short = barker[padding_len:(len(barker)-padding_len)]
    print("Len Sig Barker Short: " + str(len(barker_short)))

    axs[2].plot(barker)
    #axs[2].plot(t,barker_short)
    axs[2].set_xlabel("n")
    axs[2].set_ylabel("amplitude")
    axs[2].set_title("signal envelope correlated with barker code rect sequence")

    plt.tight_layout()
    plt.show()

def main():
    num_args = len(sys.argv) - 1

    if num_args != 1:
        ERROR_EXIT("please specify the file")
    
    file_name = sys.argv[1]
    print("Opening: " + file_name)
    
    data = None
    with open(file_name) as file_reader:
        data = json.load(file_reader)
    
    
    make_plot(data, data["codelen"])

if __name__ == "__main__":
    main()